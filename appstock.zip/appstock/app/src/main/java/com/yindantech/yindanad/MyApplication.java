package com.yindantech.yindanad;

import android.app.Application;
import android.content.Context;

import androidx.multidex.MultiDex;

import com.yindantech.ad.utli.AdUtils;


/**
 * @Description: 程序入口
 * @Author: 张梦云
 * @CreateDate: 2020/12/10 16:55
 * @Version: 1.0
 */
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        //初始化广告配置、启动预加载
        AdUtils.getInstance().init(this, BuildConfig.DEBUG);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

}
