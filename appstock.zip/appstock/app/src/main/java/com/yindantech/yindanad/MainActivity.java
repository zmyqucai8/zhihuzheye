package com.yindantech.yindanad;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.yindantech.ad.utli.AdConstant;
import com.yindantech.ad.view.AdView;

public class MainActivity extends AppCompatActivity {


    AdView adview;

    AdView adview2;

    AdView adview3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adview = findViewById(R.id.adview);
        adview2 = findViewById(R.id.adview2);
        adview3 = findViewById(R.id.adview3);



    }

    public void loadAD(View view) {
        adview.loadAD(AdConstant.AD_VERTISIG_ID_1, new AdView.OnAdListener() {
            @Override
            public void onAdShow() {
                Log.i("TAG", "广告展示");
            }

            @Override
            public void onAdClick() {
                Log.i("TAG", "广告点击");
            }

            @Override
            public void onAdClose() {
                Log.i("TAG", "广告关闭");
            }

            @Override
            public void onAdFailure() {
                Log.i("TAG", "广告加载失败");
            }
        });
        adview2.loadAD(AdConstant.AD_VERTISIG_ID_2);
        adview3.loadAD(AdConstant.AD_VERTISIG_ID_3);
    }
}