package com.yindantech.ad.service;

import android.app.Service;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.gif.GifDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.yindantech.ad.bean.AdBean;
import com.yindantech.ad.glide.GlideApp;
import com.yindantech.ad.utli.AdUtils;

import java.util.List;


/**
 * 预加载广告数据
 * 预加载完成后自动关闭
 */
public class AdService extends Service {

    /**
     * 预下载广告数据的数量
     */
    private int preLoadDataSize;

    @Override
    public void onCreate() {
        super.onCreate();
        startPreLoad();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    /**
     * 开始预下载
     */
    private void startPreLoad() {
        //先获取当前渠道所有广告信息
        AdUtils.getInstance().getAdDataList(new AdUtils.OnGetAdDataListener() {
            @Override
            public void onSuccess(List<AdBean.AdData> adBeanList) {
                AdUtils.getInstance().setAdPreLoadDataList(adBeanList);
                preLoadData(adBeanList);
            }

            @Override
            public void onFailure() {
                stopSelf();
            }
        });
    }


    /**
     * 预加载广告数据
     *
     * @param adBeanList 广告数据列表
     */
    private void preLoadData(List<AdBean.AdData> adBeanList) {
        for (int i = 0; i < adBeanList.size(); i++) {
            AdBean.AdData adBean = adBeanList.get(i);
            //预下载动态图
            if (AdUtils.getInstance().isGifImage(adBean.getMaterialUrl())) {
                GlideApp.with(this)
                        .asGif()
                        .load(adBean.getMaterialUrl())
                        .listener(new RequestListener<GifDrawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<GifDrawable> target, boolean isFirstResource) {
                                checkPreLoadComplete(adBeanList.size());
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(GifDrawable resource, Object model, Target<GifDrawable> target, DataSource dataSource, boolean isFirstResource) {
                                checkPreLoadComplete(adBeanList.size());
                                return false;
                            }
                        }).preload();
            } else {
                //预下载静态图
                GlideApp.with(this)
                        .load(adBean.getMaterialUrl())
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                checkPreLoadComplete(adBeanList.size());
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                checkPreLoadComplete(adBeanList.size());
                                return false;
                            }
                        }).preload();
            }
        }
    }


    /**
     * 检测预下载是否完成
     *
     * @param targetSize 广告数据总数量
     */
    private void checkPreLoadComplete(int targetSize) {
        preLoadDataSize++;
        if (targetSize == preLoadDataSize) {
            AdUtils.getInstance().logE(String.format("广告位数据 全部预加载完成 targetSize=%d", targetSize));
            //关闭服务
            stopSelf();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}