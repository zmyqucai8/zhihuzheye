package com.yindantech.ad.view;


import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.load.resource.gif.GifDrawable;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.yindantech.ad.R;
import com.yindantech.ad.bean.AdBean;
import com.yindantech.ad.glide.GlideApp;
import com.yindantech.ad.utli.AdConstant;
import com.yindantech.ad.utli.AdUtils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.disposables.Disposable;


/**
 * @Description: YDAdView
 * @Author: 张梦云
 * @CreateDate: 2020/12/9 15:06
 * @Version: 1.0
 */
public class AdView extends FrameLayout {

    //广告监听
    private OnAdListener mOnAdListener;
    //广告位id
    private String mAdvertisingId;
    //广告图片
    private ImageView mIvAd;
    //关闭按钮
    private ImageView mIvClose;
    private RelativeLayout mRootView;
    //广告数据
    private AdBean.AdData mAdData;

    /**
     * 构造方法
     *
     * @param context
     */
    public AdView(@NonNull Context context) {
        super(context);
        initView(context);
    }

    public AdView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView(context);
    }

    public AdView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(context);
    }

    /**
     * 初始化view
     *
     * @param context 上下文
     */
    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.layout_adview, this, true);
        mIvAd = findViewById(R.id.iv_ad);
        mIvClose = findViewById(R.id.iv_close);
        mRootView = findViewById(R.id.root_view);
        setVisibility(GONE);
        setAdClickListener();
        setCloseClickListener();
    }

    /**
     * 设置广告点击事件
     */
    private void setAdClickListener() {
        mIvAd.setOnClickListener(v -> {
            //打开广告
            AdUtils.getInstance().openAdTargetAddress(getContext(), mAdData.getTargetAddress());
            //广告点击上报
            AdUtils.getInstance().adClickReport(mAdData.getAdvertisingId());
            if (null != mOnAdListener)
                mOnAdListener.onAdClick();
        });
    }

    /**
     * 设置广告关闭点击事件
     */
    private void setCloseClickListener() {
        mIvClose.setOnClickListener(v -> {
            if (null != mOnAdListener)
                mOnAdListener.onAdClose();
            setVisibility(GONE);
//            destroy();
        });
    }

    /**
     * 加载广告
     *
     * @param advertisingId 广告位idsh
     */
    public void loadAD(String advertisingId) {
        loadAD(advertisingId, null);
    }

    /**
     * 加载广告
     *
     * @param advertisingId 广告位id
     * @param listener      监听
     */
    public void loadAD(String advertisingId, AdView.OnAdListener listener) {
        if (mRootView == null) {
            return;
        }
        this.mOnAdListener = listener;
        this.mAdvertisingId = advertisingId;

        //显示预加载数据
        AdBean.AdData adPreLoadData = AdUtils.getInstance().getAdPreLoadData(advertisingId);
        if (null != adPreLoadData) {
            loadAdData(adPreLoadData);
        } else {
            //加载新的广告数据
            loadNewAdData();
        }
        //启动延时更新广告数据
        startDelayUpdateAd();
    }

    /**
     * 加载最新的广告数据
     */
    private void loadNewAdData() {
        AdUtils.getInstance().getAdData(mAdvertisingId, new AdUtils.OnGetAdDataListener() {
            @Override
            public void onSuccess(List<AdBean.AdData> adBeanList) {
                loadAdData(adBeanList.get(0));
            }

            @Override
            public void onFailure() {
                adLoadFailed();
            }
        });

    }

    /**
     * 加载广告数据
     *
     * @param adData 广告数据
     */
    private void loadAdData(AdBean.AdData adData) {
        if (adData == null) {
            if (null != mOnAdListener) {
                mOnAdListener.onAdFailure();
            }
            return;
        }
        this.mAdData = adData;
        //加载动态图
        if (AdUtils.getInstance().isGifImage(adData.getMaterialUrl())) {
            GlideApp.with(this)
                    .asGif()
                    .load(adData.getMaterialUrl())
                    .into(new CustomTarget<GifDrawable>() {
                        @Override
                        public void onResourceReady(@NonNull GifDrawable drawable, @Nullable Transition<? super GifDrawable> transition) {
                            showAd(drawable);
                        }

                        @Override
                        public void onLoadFailed(@Nullable Drawable errorDrawable) {
                            super.onLoadFailed(errorDrawable);
                            adLoadFailed();
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }
                    });

        } else {
            //加载静态图
            GlideApp.with(this)
                    .load(adData.getMaterialUrl())
                    .into(new CustomTarget<Drawable>() {
                        @Override
                        public void onResourceReady(@NonNull Drawable drawable, @Nullable Transition<? super Drawable> transition) {
                            showAd(drawable);
                        }

                        @Override
                        public void onLoadFailed(@Nullable Drawable errorDrawable) {
                            super.onLoadFailed(errorDrawable);
                            adLoadFailed();
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }
                    });
        }
    }


    private Disposable mSubscribe;

    /**
     * 启动延时更新广告数据
     */
    private void startDelayUpdateAd() {
        stopDelayUpdateAd();
        //根据服务器配置的间隔时间，更新数据
        mSubscribe = Observable.timer(AdConstant.AD_UPDATE_DELAY_TIME, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(s -> {
                    loadNewAdData();
                });
    }

    /**
     * 停止延时更新广告数据
     */
    private void stopDelayUpdateAd() {
        if (null != mSubscribe) {
            mSubscribe.dispose();
        }
        mSubscribe = null;
    }

    /**
     * 显示广告
     *
     * @param drawable 加载的图片
     */
    private void showAd(Drawable drawable) {
        if (null == mIvAd) {
            return;
        }
        mIvAd.setImageDrawable(drawable);
        //动态调整view的宽高
        post(() -> {
            FrameLayout.LayoutParams rootViewLayoutParams;
            //目前仅适配了Amazon平板
            int ad_banner_width;
            int ad_banner_height;
            if (mAdData.getMeasure() == AdConstant.MEASURE_320x50) {
                //6.4:1的广告图
                ad_banner_width = (int) getResources().getDimension(R.dimen.ad_banner_width);
                ad_banner_height = (int) getResources().getDimension(R.dimen.ad_banner_height);
            } else {
                //1:1的广告图
                ad_banner_width = (int) getResources().getDimension(R.dimen.ad_banner_party_width);
                ad_banner_height = ad_banner_width;
            }
            rootViewLayoutParams = new LayoutParams(ad_banner_width, ad_banner_height);
            rootViewLayoutParams.gravity = Gravity.CENTER;
            mRootView.setLayoutParams(rootViewLayoutParams);
            setVisibility(VISIBLE);
            if (drawable instanceof GifDrawable) {
                //如果是gif就开始播放
                ((GifDrawable) drawable).start();
            }
            //上报显示数据
            AdUtils.getInstance().adShowReport(mAdData.getAdvertisingId());
            if (null != mOnAdListener)
                mOnAdListener.onAdShow();
        });
    }

    /**
     * 广告加载失败
     */
    private void adLoadFailed() {
        AdUtils.getInstance().logE("ad load failed");
        setVisibility(GONE);
        if (null != mOnAdListener)
            mOnAdListener.onAdFailure();
    }

    /**
     * 资源释放
     */
    public void destroy() {
        mOnAdListener = null;
        mIvAd = null;
        mIvClose = null;
        mAdData = null;
        mRootView = null;
        stopDelayUpdateAd();
    }

    /**
     * 广告监听接口
     */
    public interface OnAdListener {
        /**
         * 广告显示
         */
        void onAdShow();

        /**
         * 广告点击
         */
        void onAdClick();

        /**
         * 广告关闭
         */
        void onAdClose();

        /**
         * 广告加载失败
         */
        void onAdFailure();
    }
}
