package com.yindantech.ad.http;

import java.io.InputStream;

/**
 * HttpResponse
 */

public class HttpResponse {
    public InputStream inputStream;
    public InputStream errorStream;
    public int code;
    public long contentLength;
    public Exception exception;
}
