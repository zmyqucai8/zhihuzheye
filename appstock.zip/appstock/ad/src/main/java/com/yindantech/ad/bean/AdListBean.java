package com.yindantech.ad.bean;

import java.util.List;

/**
 * 广告数据列表数据
 */
public class AdListBean extends BaseResponse {

    private List<AdBean.AdData> data;

    public List<AdBean.AdData> getData() {
        return data;
    }

    public void setData(List<AdBean.AdData> data) {
        this.data = data;
    }
}
