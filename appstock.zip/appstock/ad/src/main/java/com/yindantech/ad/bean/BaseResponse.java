package com.yindantech.ad.bean;

/**
 * 请求返回
 */
public class BaseResponse {
    /**
     * status : 0
     * message : 操作成功！
     * data : object
     */
    private String status;

    private String message;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
