package com.yindantech.ad.bean;

/**
 * 广告数据实体对象
 */
public class AdBean extends BaseResponse {


    private AdData data;


    public AdData getData() {
        return data;
    }

    public void setData(AdData data) {
        this.data = data;
    }

    public static class AdData {
        /**
         * advertisingId : 9
         * channelId : 6
         * materialId : 3
         * measure : 2
         * materialName : family
         * materialUrl : http://www.yindantechhk.com:9000/yindandev/advertising/2020/12/16/da140b2d38354613bde5eba0f15665d4.jpg
         * targetAddress : yindanAD.com
         * targetType : 1
         * createAt : 2020-12-16 15:11:46
         */

        private String advertisingId;
        private String channelId;
        private String materialId;
        private int measure;
        private String materialName;
        private String materialUrl;
        private String targetAddress;
        private int targetType;
        private String createAt;

        public String getAdvertisingId() {
            return advertisingId;
        }

        public void setAdvertisingId(String advertisingId) {
            this.advertisingId = advertisingId;
        }

        public String getChannelId() {
            return channelId;
        }

        public void setChannelId(String channelId) {
            this.channelId = channelId;
        }

        public String getMaterialId() {
            return materialId;
        }

        public void setMaterialId(String materialId) {
            this.materialId = materialId;
        }

        public int getMeasure() {
            return measure;
        }

        public void setMeasure(int measure) {
            this.measure = measure;
        }

        public String getMaterialName() {
            return materialName;
        }

        public void setMaterialName(String materialName) {
            this.materialName = materialName;
        }

        public String getMaterialUrl() {
            return materialUrl;
        }

        public void setMaterialUrl(String materialUrl) {
            this.materialUrl = materialUrl;
        }

        public String getTargetAddress() {
            return targetAddress;
        }

        public void setTargetAddress(String targetAddress) {
            this.targetAddress = targetAddress;
        }

        public int getTargetType() {
            return targetType;
        }

        public void setTargetType(int targetType) {
            this.targetType = targetType;
        }

        public String getCreateAt() {
            return createAt;
        }

        public void setCreateAt(String createAt) {
            this.createAt = createAt;
        }
    }
}
