package com.yindantech.ad.utli;


import rxhttp.wrapper.annotation.DefaultDomain;

/**
 * @Description: 常量类
 * @Author: 张梦云
 * @CreateDate: 2020/12/11 16:37
 * @Version: 1.0
 */
public class AdConstant {

    /**
     * APP渠道id ,一个APP对应一个渠道，在配置渠道后获取对应id
     */
    public static final String CHANNEL_ID = "7";

    /**
     * 广告位id, 创建广告位后，获取id
     */
    public static final String AD_VERTISIG_ID_1 = "10";
    public static final String AD_VERTISIG_ID_2 = "11";
    public static final String AD_VERTISIG_ID_3 = "12";
    //...more


    /**
     * 服务器动态域名  从app_config。json文件读取
     * {"path":"http://yindantechhk.com:8080"}
     */
    public static final String BASE_URL_PATH_JSON = "https://www.yindantechhk.com/YinDanAD/app_config.json";

    /**
     * 服务器默认域名 ， 会读取BASE_URL_PATH_JSON重新赋值
     */
    @DefaultDomain()
    public static String BASE_URL = "http://yindantechhk.com:8080";

    /**
     * 单个广告位更新的延时时间：单位<秒> （默认10分钟）
     * 会读取服务器app_config。json文件重新赋值
     */
    public static int AD_UPDATE_DELAY_TIME = 60 * 10;

    /**
     * 广告目标类型（1：URL，2：AppStore，3：Shop）
     */
    public static final int TARGET_TYPE_URL = 1;
    public static final int TARGET_TYPE_APPSTORE = 2;
    public static final int TARGET_TYPE_SHOP = 3;

    /**
     * 广告位尺寸（1表示：320*50，2表示：250*250）
     */
    public static final int MEASURE_320x50 = 1;
    public static final int MEASURE_250x250 = 2;

    /**
     * 广告上报类型 1=显示 2=点击
     */
    public static final int AD_REPORT_TYPE_SHOW = 1;
    public static final int AD_REPORT_TYPE_CLICK = 2;

    /**
     * API 获取广告数据
     *
     * @param channelId：渠道id
     * @param advertisingId：广告位id
     */
    public static final String API_GET_AD_DATA = "/amazon/get";


    /**
     * API 获取广告数据 ，渠道下所有的
     *
     * @param channelId：渠道id
     */
    public static final String API_GET_AD_DATA_LIST = "/amazon/list";
    /**
     * API 广告点击、显示上报
     *
     * @param advertisingId：广告位id
     * @param type :1：展现统计，2：点击量统计
     */
    public static final String API_AD_CLICK_SHOW_PEPORT = "/amazon/add";


    /**
     * Key
     */
    //渠道id
    public static final String KEY_CHANNEL_ID = "channelId";
    //广告位id
    public static final String KEY_ADVERTISING_ID = "advertisingId";
    //path
    public static final String KEY_PATH = "path";
    //android_task
    public static final String KEY_ANDROID_TASK = "android_task";
    //type
    public static final String KEY_TYPE = "type";


}
