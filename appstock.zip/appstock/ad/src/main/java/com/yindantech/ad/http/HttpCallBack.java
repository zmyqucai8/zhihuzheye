package com.yindantech.ad.http;

import android.os.Handler;
import android.os.Looper;

import com.google.gson.Gson;
import com.yindantech.ad.bean.BaseResponse;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * http请求回调
 */

public abstract class HttpCallBack<T> {

    /**
     * MainHandler
     */
    static Handler mMainHandler = new Handler(Looper.getMainLooper());

    /**
     * 失败回调
     *
     * @param response
     */
    void onError(final HttpResponse response) {

        final String errorMessage;
        if (response.inputStream != null) {
            errorMessage = getRetString(response.inputStream);
        } else if (response.errorStream != null) {
            errorMessage = getRetString(response.errorStream);
        } else if (response.exception != null) {
            errorMessage = response.exception.getMessage();
        } else {
            errorMessage = "";
        }
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                onFailure(response.code, errorMessage);
            }
        });
    }

    /**
     * 成功回调
     *
     * @param response
     */
    void onSeccess(HttpResponse response) {
        final T obj = onParseResponse(response);
        mMainHandler.post(new Runnable() {
            @Override
            public void run() {
                onResponse(obj);
            }
        });
    }


    /**
     * 解析response，执行在子线程
     */
    public abstract T onParseResponse(HttpResponse response);

    /**
     * 访问网络失败后被调用，执行在UI线程
     */
    public abstract void onFailure(int code, String errorMessage);

    /**
     * 访问网络成功后被调用，执行在UI线程
     */
    public abstract void onResponse(T response);


    /**
     * 返回String
     */
    public static abstract class CallBackString extends HttpCallBack<String> {
        @Override
        public String onParseResponse(HttpResponse response) {
            try {
                return getRetString(response.inputStream);
            } catch (Exception e) {
                throw new RuntimeException("failure");
            }
        }
    }


    /**
     * 获取string
     *
     * @param is InputStream
     * @return
     */
    private static String getRetString(InputStream is) {
        String buf;
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"));
            StringBuilder sb = new StringBuilder();
            String line = "";
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                sb.append("\n");
            }
            is.close();
            buf = sb.toString();
            return buf;

        } catch (Exception e) {
            return null;
        }
    }

}
