package com.yindantech.ad.utli;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.yindantech.ad.bean.AdBean;
import com.yindantech.ad.bean.AdListBean;
import com.yindantech.ad.http.HttpCallBack;
import com.yindantech.ad.http.HttpUtils;
import com.yindantech.ad.service.AdService;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.schedulers.Schedulers;


/**
 * @Description: 广告工具类
 * @Author: 张梦云
 * @CreateDate: 2020/12/9 15:06
 * @Version: 1.0
 */
public class AdUtils {


    /**
     * 实例对象
     */
    private static AdUtils instance;

    /**
     * 获取实例
     *
     * @return
     */
    public static AdUtils getInstance() {
        if (null == instance) {
            instance = new AdUtils();
        }
        return instance;
    }


    public void init(Context context) {
        init(context, false);
    }


    /**
     * 是否debug模式（打印log）
     */
    private boolean mIsDebug;

    /**
     * 初始化
     * 1、先读取服务器配置文件：域名、广告位刷新间隔时间
     * 2、启动渠道下所有广告位的数据预加载 服务（完成后自动关闭服务）
     *
     * @param context
     * @param
     */
    public void init(Context context, boolean isDebug) {
        this.mIsDebug = isDebug;
        //先去获取服务器配置
        HttpUtils.get(AdConstant.BASE_URL_PATH_JSON, new HttpCallBack.CallBackString() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    AdConstant.BASE_URL = jsonObject.getString(AdConstant.KEY_PATH);
                    AdConstant.AD_UPDATE_DELAY_TIME = jsonObject.getInt(AdConstant.KEY_ANDROID_TASK);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                logI(String.format("setServiceDomain success: BASE_URL=%s", AdConstant.BASE_URL));
                //启动预加载数据服务
                startPreLoadService(context);
            }

            @Override
            public void onFailure(int code, String errorMessage) {
                //启动预加载数据服务
                startPreLoadService(context);
            }

        });
    }


    /**
     * 启动广告预下载服务
     *
     * @param context
     */
    private void startPreLoadService(Context context) {
        Intent intent = new Intent(context, AdService.class);
        context.startService(intent);
    }

    /**
     * 广告预下载数据列表
     */
    private List<AdBean.AdData> adPreLoadDataList;

    /**
     * 获取广告预下载数据列表
     *
     * @return List<AdBean>
     */
    public List<AdBean.AdData> getAdPreLoadDataList() {
        return adPreLoadDataList;
    }

    /**
     * 保存广告预下载数据列表
     *
     * @param adPreLoadDataList
     */
    public void setAdPreLoadDataList(List<AdBean.AdData> adPreLoadDataList) {
        this.adPreLoadDataList = adPreLoadDataList;
    }


    /**
     * 根据广告位id， 获取广告预下载数据
     *
     * @param advertisingId 广告位id
     * @return AdBean 广告位数据
     */
    public AdBean.AdData getAdPreLoadData(String advertisingId) {
        if (null != getAdPreLoadDataList()) {
            for (int i = 0; i < getAdPreLoadDataList().size(); i++) {
                if (getAdPreLoadDataList().get(i).getAdvertisingId().equals(advertisingId)) {
                    return getAdPreLoadDataList().get(i);
                }
            }
        }
        return null;
    }


    /**
     * 广告点击上报
     */
    public void adClickReport(String advertisingId) {
        adReport(AdConstant.AD_REPORT_TYPE_CLICK, advertisingId);
    }

    /**
     * 广告显示上报
     */
    public void adShowReport(String advertisingId) {
        adReport(AdConstant.AD_REPORT_TYPE_SHOW, advertisingId);
    }

    /**
     * 广告统计上报
     *
     * @param type 1：展现统计，2：点击量统计
     */
    private void adReport(int type, String advertisingId) {
        HashMap<String, String> paramsMap = new HashMap<>();
        paramsMap.put(AdConstant.KEY_ADVERTISING_ID, advertisingId);
        paramsMap.put(AdConstant.KEY_TYPE, String.valueOf(type));
        HttpUtils.put(AdConstant.BASE_URL + AdConstant.API_AD_CLICK_SHOW_PEPORT, paramsMap, new HttpCallBack.CallBackString() {
            @Override
            public void onFailure(int code, String errorMessage) {
            }

            @Override
            public void onResponse(String response) {
                logE(String.format("%s上报结果=%s", type == AdConstant.AD_REPORT_TYPE_SHOW ? "展示" : "点击", response));
            }
        });

    }


    /**
     * 获取单个广告位数据（根据广告位ID获取）
     *
     * @param advertisingId 广告位id
     * @param listener
     */
    public void getAdData(String advertisingId, @NotNull OnGetAdDataListener listener) {

        HashMap<String, String> paramsMap = new HashMap<>();
        paramsMap.put(AdConstant.KEY_CHANNEL_ID, AdConstant.CHANNEL_ID);
        paramsMap.put(AdConstant.KEY_ADVERTISING_ID, advertisingId);
        HttpUtils.get(AdConstant.BASE_URL + AdConstant.API_GET_AD_DATA, paramsMap, new HttpCallBack.CallBackString() {
            @Override
            public void onFailure(int code, String errorMessage) {
                listener.onFailure();
            }

            @Override
            public void onResponse(String response) {
                AdBean adBean = new Gson().fromJson(response, AdBean.class);
                if (null != adBean && adBean.getStatus().equals("0")) {
                    ArrayList list = new ArrayList<>();
                    list.add(adBean.getData());
                    listener.onSuccess(list);
                } else {
                    listener.onFailure();
                }

            }
        });
    }


    /**
     * 获取当前渠道下所有的广告数据list
     *
     * @param listener
     */
    public void getAdDataList(@NotNull OnGetAdDataListener listener) {
        HashMap<String, String> paramsMap = new HashMap<>();
        paramsMap.put(AdConstant.KEY_CHANNEL_ID, AdConstant.CHANNEL_ID);
        HttpUtils.get(AdConstant.BASE_URL + AdConstant.API_GET_AD_DATA_LIST, paramsMap, new HttpCallBack.CallBackString() {
            @Override
            public void onFailure(int code, String errorMessage) {
                listener.onFailure();
            }

            @Override
            public void onResponse(String response) {
                AdListBean adListBean = new Gson().fromJson(response, AdListBean.class);
                if (null != adListBean && adListBean.getStatus().equals("0")) {
                    listener.onSuccess(adListBean.getData());
                } else {
                    listener.onFailure();
                }

            }
        });

    }


    /**
     * 打开广告目标地址
     *
     * @param targetAddress 目标地址
     */
    public void openAdTargetAddress(Context context, String targetAddress) {
        if (TextUtils.isEmpty(targetAddress)) {
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(targetAddress));
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 判断是否gif图
     *
     * @param imageUrl
     * @return
     */
    public boolean isGifImage(String imageUrl) {
        return !TextUtils.isEmpty(imageUrl) && (imageUrl.endsWith(".gif") || imageUrl.endsWith(".GIF"));
    }


    /**
     * 清除广告图片缓存
     *
     * @return
     */
    public void clearAdImageChace(Context context) {
        Observable.create(emitter -> Glide.get(context).clearDiskCache())
                .subscribeOn(Schedulers.io())
                .subscribe();
    }

    /**
     * 输出error日志
     *
     * @param string
     */
    public void logE(String string) {
        if (mIsDebug)
            Log.e("AD", string);
    }

    /**
     * 输出info日志
     *
     * @param string
     */
    public void logI(String string) {
        if (mIsDebug)
            Log.i("AD", string);
    }

    /**
     * 获取广告数据监听
     */
    public interface OnGetAdDataListener {
        void onSuccess(List<AdBean.AdData> adDataList);

        void onFailure();
    }


}
